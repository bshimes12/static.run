# Birthday Page Design Spec

## Overview

An interactive birthday page for static.run (`birthday.html`) featuring a gift box that grows on click, then explodes into a screen-filling celebration of confetti, balloons, streamers, and colored balls, ending with a personalized "Happy Birthday [Name]!" message.

Personalized via query parameter: `?name=Sarah` → "Happy Birthday Sarah!" (defaults to "Happy Birthday!" with no param).

## Approach

Pure CSS animations + JS orchestration. No external dependencies. Single self-contained HTML file with inline CSS/JS. SVG gift box, DOM-based particles, CSS transforms for animation.

## Visual Style

- **Present:** Elegant & fancy — purple (`#6c5ce7`) body with gradient, gold (`#ffd700`) ribbon/bow, sparkle accents. Inspired by the chosen mockup with rich gradients and decorative details.
- **Particle colors:** Fully saturated rainbow — red, pink, gold, green, blue, purple, orange. No dull or muted colors.
- **Final text:** White, bold, with subtle drop shadow for legibility over the chaotic colorful background.
- **Background:** Dark (`#0a0a1a`) initially, transforms into color via the accumulated particle debris.

## Initial State (Before Click)

- Dark background (`#0a0a1a`)
- Centered small gift box (~80px) — purple/gold SVG with gradient body, gold ribbon, elaborate bow, sparkles
- Above box: "Happy Birthday" in subtle soft white text (warm intro, not the final big version)
- Below box: "Click me!" with a gentle pulse animation
- Present has idle animation: sparkle twinkle, slight float/bob

## Animation Sequence (~6-8 seconds)

### Phase 1 — Present Growth (~3 seconds)

On click:
- "Click me!" text fades out
- Present scales from ~80px to ~300px via CSS `transform: scale()` with `cubic-bezier(0.34, 1.56, 0.64, 1)` (slight overshoot)
- As it grows, wrapping gains detail: decorative pattern lines appear (CSS opacity transitions on detail layers)
- Bow becomes more elaborate — extra loops and curling ribbon tails
- Sparkles multiply and intensify
- Subtle glow builds behind present (purple/gold radial gradient)
- "Happy Birthday" intro text fades out

### Phase 2 — Anticipation (~1 second)

- Present at full size, pauses
- Wobble/shake builds — something pushing from inside
- Wobble intensifies, glow pulses

### Phase 3 — Explosion (~0.5 seconds)

- Lid launches upward and off-screen
- Box sides burst outward and fade
- From center, everything erupts simultaneously:
  - **Balloons** (10-15): various colors, float upward with slight lateral drift
  - **Confetti** (100+): small rectangles and circles, every color, scatter in all directions with gravity
  - **Streamers** (8-12): long curling ribbon strips, spiral outward
  - **Colored balls** (20-30): solid circles, bounce/scatter to edges

### Phase 4 — Fill & Settle (~2-3 seconds)

- Particles spread to fill entire screen
- Background transforms from dark to color — the accumulated particle debris IS the background
- Final "Happy Birthday [Name]!" text fades in: large, bold, white, centered, on top of all the color

### Phase 5 — Ambient (indefinite)

- Confetti continues gently drifting down
- Balloons slowly float and bob
- Streamers sway
- Screen stays alive and celebratory

## Particle Implementation

Each particle type is a `<div>` with absolute positioning, spawned by JS at explosion with randomized properties:

- **Confetti:** Small rectangles/circles. Randomized initial angle, velocity, size, color, rotation. CSS `flutter` animation (multi-axis rotation as it falls). ~100+ elements.
- **Balloons:** Larger oval divs. CSS `float` animation (translateY oscillation + slight rotation). Continuous gentle bobbing. ~10-15 elements.
- **Streamers:** Tall thin divs. CSS `wave` animation (sinusoidal sway). ~8-12 elements.
- **Colored balls:** Solid circles. Scatter to edges then settle. ~20-30 elements.

Total DOM particles: ~150-200 (well within browser performance limits).

All movement via CSS transforms (GPU-accelerated, no layout thrashing).

## Present SVG

- Built inline in the HTML
- Same elegant style as chosen mockup: purple gradient body, gold gradient ribbon, elaborate bow with multiple loops, sparkle accents
- Growth via CSS `transform: scale()` on wrapper div
- Detail enhancement during growth: hidden detail layers fade in via CSS opacity transitions

## Query Parameter

- `?name=Sarah` → final message reads "Happy Birthday Sarah!"
- No parameter → "Happy Birthday!"
- Parsed via `URLSearchParams`

## Performance Targets

- 60fps animation on modern browsers
- ~150-200 DOM elements for particles
- CSS transforms are GPU-accelerated
- Single file, no dependencies, target under 15KB
- Works on desktop and mobile browsers

## File

`birthday.html` in project root, added to `index.html` grid via the static.run workflow.
